CarLife Bridge (Samsung Galaxy S26 Ultra -> Jetta VS7 MQB)
==========================================================
Версия: 1.2 (Release Signed APK)
Файл APK: CarLifeBridge-Release-Signed-S26Ultra.apk
Размер: 2845610 Б (2.71 МБ)
SHA-256: b0251b1bb4711db3328b2e4acd8af05b41913760b13dd95eba0727d11e56821a

Ключевые возможности сборки:
1. Переключатель 3 независимых режимов работы (с сохранением в SharedPreferences):
   - «Кокпит (Стандартный)»: тач 0x0006 идёт строго в Presentation.decorView (без AccessibilityService).
   - «Зеркалирование (Экран телефона)»: захват всего экрана через MediaProjectionConfig.createConfigForDefaultDisplay() (Android 14–16), одноразовое потребление токена resultData без переиспользования просроченного Intent, строгий запрет тихого отката в Кокпит и панель диагностики MediaProjection на экране.
   - «Кокпит + Shizuku (Второй экран)»: VirtualDisplay (1280x720 @ 30fps, 160 dpi), запуск приложений через Shizuku UserService (am start --display <id>) в обход ограничений Android 16, низколатентный тач 0x0006 (InputManager.injectInputEvent) и системные клавиши (Home/Back) без AccessibilityService.
2. Оптимизация H.264 MediaCodec (MediaFormatUtils + фикс 120 Гц экрана S26 Ultra):
   - 1280x720 @ 30 fps, 2 000 000 bps, VBR (BITRATE_MODE_VBR), AVCProfileBaseline + AVCLevel3,
     KEY_FRAME_RATE=30, KEY_MAX_FPS_TO_ENCODER=30f, KEY_CAPTURE_RATE=30,
     KEY_I_FRAME_INTERVAL=1, KEY_REPEAT_PREVIOUS_FRAME_AFTER=100000, KEY_PRIORITY=0, video-qp-p-max=36.
3. Приоритетная очередь USB AOA (CarLifeUsbWriterThread / LinkedBlockingQueue):
   - Пакеты звука 0x0003 и управления 0x0001 имеют приоритет над видео 0x0002.
   - Устаревшие P-кадры 0x0002 при переполнении очереди сбрасываются без накопления задержки.
   - Логирование пакетов в UI по умолчанию выключено.
4. Звук по USB 0x0003 (AudioPlaybackCapture):
   - 48 кГц Stereo 16-bit PCM, автоматическое приглушение динамика телефона (STREAM_MUSIC = 0)
     и восстановление исходной громкости при отключении USB / остановке сервиса.
