CarLife Bridge (Jetta VS7 / Samsung Galaxy S26 Ultra)
Release Signed APK — CarLifeBridge-Release-Signed-S26Ultra.apk
SHA-256: 921d5bdfd539c28003f2cc91a6446ca5ce685adeedf071db1197bc219e4118ab
Размер: 2802098 байт (2.67 МБ)

Основные изменения в этой сборке:
1. Главный переключатель режима работы вверху Настроек:
   - «Кокпит (Виртуальный экран)» (AppMode.COCKPIT)
   - «Зеркалирование (Экран телефона)» (AppMode.MIRRORING)
   При переключении корректно останавливается текущий видеоисточник и запускается выбранный (токен MediaProjection сохраняется).
2. Изолированная маршрутизация тача (канал 0x0006):
   - COCKPIT: строго в Presentation.window.decorView.dispatchTouchEvent с сохранением lastDownTime (1280x720), без CarLifeAccessibilityService.
   - MIRRORING: строго в CarLifeAccessibilityService (dispatchGesture) с пересчётом координат в currentWindowMetrics.bounds.
3. Устранены тормоза в режиме «Зеркалирование»:
   - MediaCodec 1280x720@30fps, 2000 kbps: KEY_PRIORITY=0, KEY_OPERATING_RATE=30, KEY_I_FRAME_INTERVAL=1; VirtualDisplay DPI = 200 (160–240).
   - Выделенный высокоприоритетный USB-писатель (CarLifeUsbWriterThread + LinkedBlockingQueue) для неблокирующей отправки видео 0x0002 и аудио 0x0003.
   - Тумблер «Логировать пакеты в UI» (выключен по умолчанию в режиме Зеркалирования) + пакетное обновление статистики.
   - Исправлен deadlock при остановке сервиса (безопасное закрытие Presentation без блокировки главного потока).
4. Автоотключение динамика телефона при USB-звуке (канал 0x0003):
   - Тумблер «Глушить динамик телефона при USB-звуке» (включён по умолчанию).
   - Сохраняет STREAM_MUSIC, ставит громкость в 0 при старте AudioPlaybackCapture и автоматически восстанавливает при остановке/отключении USB.
