CarLife Bridge (Samsung Galaxy S26 Ultra -> Jetta VS7 MQB)
==========================================================
Версия: 1.1 (Release Signed APK)
Файл APK: CarLifeBridge-Release-Signed-S26Ultra.apk
SHA-256: cb03c4cd2f64f022674701223dcee038f44e18dbf28859588e169ee3c3a4fa31

Ключевые возможности сборки:
1. Переключатель 2 режимов:
   - «Кокпит (Виртуальный экран)»: тач 0x0006 идёт строго в Presentation.decorView (без AccessibilityService).
   - «Зеркалирование (Экран телефона)»: захват MediaProjection (180 dpi) + тач 0x0006 строго через CarLifeAccessibilityService.
2. Оптимизация H.264 MediaCodec (MediaFormatUtils):
   - 1280x720 @ 30 fps, 2 000 000 bps, VBR (BITRATE_MODE_VBR), AVCProfileBaseline + AVCLevel3,
     KEY_I_FRAME_INTERVAL=1, KEY_REPEAT_PREVIOUS_FRAME_AFTER=100000, KEY_PRIORITY=0, video-qp-p-max=36.
3. Приоритетная очередь USB AOA (CarLifeUsbWriterThread / LinkedBlockingQueue):
   - Пакеты звука 0x0003 и управления 0x0001 имеют приоритет над видео 0x0002.
   - Устаревшие P-кадры 0x0002 при >5 кадрах в очереди сбрасываются без накопления задержки.
   - Логирование пакетов в UI по умолчанию выключено.
4. Звук по USB 0x0003 (AudioPlaybackCapture):
   - 48 кГц Stereo 16-bit PCM, автоматическое приглушение динамика телефона (STREAM_MUSIC = 0)
     и восстановление исходной громкости при отключении USB / остановке сервиса.
